## TetrisGame based on AngularJS and NodeJS

This project contains the Tetris Game.
In order to start playing it, start the Node js server and type your nickname.

## Usage

Type "node index.js" into your terminal to start the node server.
Go to localhost:3000 in your Browser and have fun!

## Installation

You will need to have a working Node installation running.
